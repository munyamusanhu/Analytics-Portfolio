import pandas as pd
import numpy as np
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
import matplotlib.pyplot as plt
import seaborn as sns
import re
import os
"""
MAIN.py

Runs cosine similarity analysis comparing baseline and the different responses from the trails. 
Generates histograms, boxplots, and the heatmaps included in the report.
"""
def main():
    def preprocess_text(text):
        text = str(text).lower()
        text = re.sub(r'[^\w\s]', '', text)  # remove punctuation
        text = re.sub(r'\s+', ' ', text).strip()  # remove extra spaces
        return text


    baseline_csv = "data/results_baseline.csv"
    baseline_df = pd.read_csv(baseline_csv)
    baseline_df['explanation_clean'] = baseline_df['explanation'].apply(preprocess_text)


    experiment_files = [
        "data/results_demog_temp0.csv",
        "data/results_demog_temp1.csv",
        "data/trial2/results_demog_temp0_noage.csv",
        "data/trial2/results_demog_temp1_noage.csv",
        "data/trial3/results_demog_temp0_noage_newprompt.csv",
        "data/trial3/results_demog_temp1_noage_newprompt.csv",
    ]

    experiment_names = [
        "Trial 1 Temp 0",
        "Trial 1 Temp 1",
        "Trial 2 Temp 0",
        "Trial 2 Temp 1",
        "Trial 3 Temp 0",
        "Trial 3 Temp 1"
    ]


    model = SentenceTransformer('all-MiniLM-L6-v2')
    baseline_embeddings = model.encode(baseline_df['explanation_clean'].tolist())

    all_similarity_dfs = []

    for exp_file, exp_name in zip(experiment_files, experiment_names):
        if not os.path.exists(exp_file):
            print(f"Skipping missing file: {exp_file}")
            continue

        variant_df = pd.read_csv(exp_file)
        variant_df['explanation_clean'] = variant_df['explanation'].apply(preprocess_text)

        merged_df = variant_df.merge(
            baseline_df[['client_id', 'explanation_clean']],
            on='client_id',
            how='left',
            suffixes=('', '_baseline')
        )

        # Align baseline embeddings
        baseline_index_map = {cid: idx for idx, cid in enumerate(baseline_df['client_id'])}
        baseline_emb_aligned = [baseline_embeddings[baseline_index_map[cid]] for cid in merged_df['client_id']]

        variant_embeddings = model.encode(merged_df['explanation_clean'].tolist())

        # Compute cosine similarity
        merged_df['cosine_similarity'] = [
            cosine_similarity([b], [v])[0][0] for b, v in zip(baseline_emb_aligned, variant_embeddings)
        ]

        merged_df['Experiment'] = exp_name
        all_similarity_dfs.append(merged_df)

    # Combine all experiments
    combined_df = pd.concat(all_similarity_dfs, ignore_index=True)


    plt.figure(figsize=(10, 6))
    for exp_name, group_df in combined_df.groupby('Experiment'):
        sns.histplot(group_df['cosine_similarity'], bins=30, label=exp_name, alpha=0.5)
    plt.axvline(0.90, color='red', linestyle='--', label='0.9 Threshold')
    plt.xlabel("Cosine Similarity")
    plt.ylabel("Frequency")
    plt.title("Cosine Similarity Distributions Across Experiments")
    plt.legend()
    plt.show()

    plt.figure(figsize=(10, 6))
    sns.boxplot(x='Experiment', y='cosine_similarity', data=combined_df)
    plt.axhline(0.90, color='red', linestyle='--', label='0.9 Threshold')
    plt.ylabel("Cosine Similarity")
    plt.title("Cosine Similarity Across Experiments")
    plt.xticks(rotation=45)
    plt.show()


    demographics = ['gender', 'race', 'age']

    for demo in demographics:
        plt.figure(figsize=(12, 6))
        sns.boxplot(x='Experiment', y='cosine_similarity', hue=demo, data=combined_df)
        plt.axhline(0.90, color='red', linestyle='--', label='0.9 Threshold')
        plt.title(f"Cosine Similarity Across Experiments by {demo.capitalize()}")
        plt.ylabel("Cosine Similarity")
        plt.xticks(rotation=45)
        plt.legend(title=demo.capitalize(), bbox_to_anchor=(1.05, 1), loc='upper left')
        plt.tight_layout()
        plt.show()


    for demo in demographics:
        pivot = combined_df.pivot_table(
            index=demo,
            columns='Experiment',
            values='cosine_similarity',
            aggfunc='mean'
        )

        plt.figure(figsize=(10, 6))
        sns.heatmap(pivot, annot=True, fmt=".2f", cmap='coolwarm', vmin=0.8, vmax=1.0)
        plt.title(f"Mean Cosine Similarity by {demo.capitalize()} and Experiment")
        plt.ylabel(demo.capitalize())
        plt.xlabel("Experiment")
        plt.show()

if __name__ == "__main__":
    main()