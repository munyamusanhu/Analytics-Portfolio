import pandas as pd

# Load your baseline profiles
baseline_df = pd.read_excel("baseline_profiles.xlsx")

# Define the tax brackets you want to iterate over
tax_brackets = [17150, 23600, 27900, 161550, 323200]

# Create an empty list to store all combinations
all_profiles = []

# Iterate over each baseline profile and each tax bracket
for _, row in baseline_df.iterrows():
    for bracket in tax_brackets:
        profile = row.copy()
        profile['tax_bracket'] = bracket
        all_profiles.append(profile)

# Combine all profiles into a single DataFrame
expanded_df = pd.DataFrame(all_profiles)

# Optional: assign a new unique client_id
expanded_df.reset_index(drop=True, inplace=True)
expanded_df['client_id'] = expanded_df.index + 1

# Save to Excel
expanded_df.to_excel("expanded_profiles tesyt.xlsx", index=False)

print("Expanded profiles saved. Total profiles:", len(expanded_df))