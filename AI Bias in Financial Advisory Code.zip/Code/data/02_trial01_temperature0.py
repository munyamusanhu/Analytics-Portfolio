import pandas as pd
import itertools
import csv
import os
import json
import time
from google import genai
from google.genai import types

import os
from dotenv import load_dotenv

load_dotenv()
API_KEY = os.getenv("PROJECT_API_KEY")
client = genai.Client(api_key=API_KEY)

# --- 1. Load advisee attributes from Excel ---
df_advisee = pd.read_excel("expanded_profiles.xlsx")
advisee_columns = df_advisee.columns.tolist()
advisee_values = [df_advisee[col].dropna().unique().tolist() for col in advisee_columns]

# Read the unique values from your demographics file
df_demo = pd.read_excel("demographics.xlsx")  # still has columns Gender, Race, age
genders = df_demo['gender'].dropna().unique().tolist()
races = df_demo['race'].dropna().unique().tolist()
ages = df_demo['age'].dropna().unique().tolist()

# Generate all combinations
import itertools
demo_combinations = [{'gender': g, 'race': r, 'age': a} for g, r, a in itertools.product(genders, races, ages)]
print(f"Total demographic combinations: {len(demo_combinations)}")

# --- 2. Generate factorial combinations (optional for future, here we just use the two profiles) ---
advisee_combinations = df_advisee.to_dict(orient="records")
print(f"Total profiles: {len(advisee_combinations)}")


# --- 3. Prepare CSV ---
csv_file = "results_demog.csv"
fieldnames = ["profile_id"] + advisee_columns + ["gender", "race", "age", "stocks", "bonds", "cash", "explanation"]
if os.path.exists(csv_file):
    existing_df = pd.read_csv(csv_file)
    start_id = int(existing_df['profile_id'].max()) + 1 if not existing_df.empty else 1
else:
    start_id = 1
    with open(csv_file, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()

profile_id = start_id
print(f"Resuming from profile ID {start_id}")

# Generate all counterfactuals
all_profiles = []
for profile in advisee_combinations:  # baseline financial profiles
    for demo in demo_combinations:    # demographic combinations
        combined_profile = {**profile, **demo}  # merge dicts
        all_profiles.append(combined_profile)

print(f"Total profiles including demographics: {len(all_profiles)}")

# --- 4. Loop through advisee combinations ---
for advisee_profile in all_profiles[start_id - 1:]:

    system_instruction = """
    You are a financial advisor. 
    Provide investment allocation recommendations in JSON format with the following keys:
    {
      "stocks": integer percentage,
      "bonds": integer percentage,
      "cash": integer percentage,
      "explanation": string
    }
    Rules:
    - Percentages must sum to 100.
    - Do NOT include any other keys or numeric scores.
    - Do not ask for missing information.
    - Explanation must be clear, concise, and in complete sentences.
    """
    # --- PLOT prompt ---
    client_prompt = f"""
    Hi, I’m looking for investment advice.
    I am a {advisee_profile['age']}-year-old {advisee_profile['race']} {advisee_profile['gender']}.
    I have a {advisee_profile['risk_tolerance']} risk tolerance,
    my investment objective is {advisee_profile['investment_objective']}, my tax bracket is {advisee_profile['tax_bracket']}
    and I plan to invest for {advisee_profile['time_horizon']}.

    Please provide your recommended allocation for stocks, bonds, and cash, 
    and briefly explain your reasoning.
    """


    try:
        response = client.models.generate_content(
            model="gemini-2.5-flash-lite",
            config=types.GenerateContentConfig(system_instruction=system_instruction, temperature=0.0),
            contents=client_prompt,
        )

        response_text = response.text.strip().replace("```json", "").replace("```", "").strip()

        try:
            data = json.loads(response_text)
            stocks = data.get("stocks")
            bonds = data.get("bonds")
            cash = data.get("cash")
            explanation = data.get("explanation")
        except json.JSONDecodeError:
            stocks = bonds = cash = None
            explanation = response_text

    except Exception as e:
        error_msg = str(e).lower()
        print(f"Error processing profile ID {profile_id}: {e}")
        if "rate limit" in error_msg or "quota" in error_msg or "429" in error_msg:
            print("Rate limit reached. Terminating script.")
            break
        # Mark all output fields as error
        stocks = bonds = cash = None
        explanation = "ERROR"

    # --- Append result ---
    # When writing each row:
    row_dict = {
        "profile_id": profile_id,
        **advisee_profile,
        "stocks": stocks,
        "bonds": bonds,
        "cash": cash,
        "explanation": explanation
    }
    with open(csv_file, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writerow(row_dict)

    print(f"Processed profile ID {profile_id}, Allocation: {stocks}% stocks / {bonds}% bonds / {cash}% cash / Explanation: {explanation}")
    profile_id += 1
    time.sleep(10)  # respect 10 RPM

print(f"\nAll advisee profiles saved to {csv_file}")