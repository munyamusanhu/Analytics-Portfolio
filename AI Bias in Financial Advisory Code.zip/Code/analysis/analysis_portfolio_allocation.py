import pandas as pd
from scipy.stats import ttest_rel, f_oneway
import os

# ---------------------------
baseline_csv = "results_baseline.csv"
experiments = [
    {"csv": "results_demog_temp0.csv", "name": "Results 1 Temp 0", "demographics": ["gender", "race", "age"]},
    {"csv": "results_demog_temp1.csv", "name": "Results 1 Temp 1", "demographics": ["gender", "race", "age"]},
    {"csv": "../data/trial2/results_demog_temp0_noage.csv", "name": "Results 2 Temp 0", "demographics": ["gender", "race"]},
    {"csv": "../data/trial2/results_demog_temp1_noage.csv", "name": "Results 2 Temp 1", "demographics": ["gender", "race"]},
    {"csv": "../data/trial3/results_demog_temp0_noage_newprompt.csv", "name": "Results 3 Temp 0",
     "demographics": ["gender", "race"]},
    {"csv": "../data/trial3/results_demog_temp1_noage_newprompt.csv", "name": "Results 3 Temp 1",
     "demographics": ["gender", "race"]},
]
allocations = ['stocks', 'bonds', 'cash']

# Load baseline
baseline_df = pd.read_csv(baseline_csv)

# Store combined results
results_list = []

for exp in experiments:
    if not os.path.exists(exp['csv']):
        print(f"Skipping {exp['csv']}, file not found.")
        continue

    exp_df = pd.read_csv(exp['csv'])
    merged = exp_df.merge(baseline_df[['client_id'] + allocations], on='client_id', suffixes=('', '_baseline'))

    row = {"Experiment": exp['name']}

    # Track significance
    significant_any = False

    # Paired t-tests
    for col in allocations:
        t_stat, p_val = ttest_rel(merged[col], merged[f"{col}_baseline"])
        row[f"{col}_p"] = p_val
        if p_val < 0.05:
            significant_any = True

    # ANOVA by demographic
    for demo in exp['demographics']:
        if demo not in merged.columns:
            continue
        for col in allocations:
            group_values = [group[col].values for name, group in merged.groupby(demo)]
            if len(group_values) > 1:
                f_stat, p_val = f_oneway(*group_values)
                row[f"{col}_{demo}_p"] = p_val
                if p_val < 0.05:
                    significant_any = True
            else:
                row[f"{col}_{demo}_p"] = None

    # Flag any significant differences
    row['Significant_Difference'] = significant_any
    results_list.append(row)

# Create DataFrame
combined_results = pd.DataFrame(results_list)

# Save to CSV
combined_results.to_csv("experiment_stat_tests_summary.csv", index=False)
print("All results saved to 'experiment_stat_tests_summary.csv'")