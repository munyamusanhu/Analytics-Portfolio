import pandas as pd
import numpy as np
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
import matplotlib.pyplot as plt


from sklearn.decomposition import PCA


# Replace with your file paths
baseline_csv = "../data/results_baseline.csv"
variant_csv = "../data/results_demog_temp0.csv"

baseline_df = pd.read_csv(baseline_csv)
variant_df = pd.read_csv(variant_csv)

# Merge on client_id to align baseline with each variant
merged_df = variant_df.merge(
    baseline_df[['client_id', 'explanation']],
    on='client_id',
    how='left',
    suffixes=('', '_baseline')
)


import re


def preprocess_text(text):
    text = str(text).lower()
    text = re.sub(r'[^\w\s]', '', text)  # remove punctuation
    text = re.sub(r'\s+', ' ', text).strip()  # remove extra spaces
    return text


merged_df['explanation_clean'] = merged_df['explanation'].apply(preprocess_text)
merged_df['baseline_clean'] = merged_df['explanation_baseline'].apply(preprocess_text)

# ---------------------------
# Step 3: Generate Semantic Embeddings
# ---------------------------
# Using Sentence-BERT (fast, open-source)
model = SentenceTransformer('all-MiniLM-L6-v2')

baseline_embeddings = model.encode(merged_df['baseline_clean'].tolist())
variant_embeddings = model.encode(merged_df['explanation_clean'].tolist())

print(f"baseline_embeddings: {baseline_embeddings}")
print(f"variant_embeddings: {variant_embeddings}")
# ---------------------------
# Step 4: Compute Cosine Similarity
# ---------------------------
similarities = []
for base_vec, var_vec in zip(baseline_embeddings, variant_embeddings):
    sim = cosine_similarity([base_vec], [var_vec])[0][0]
    similarities.append(sim)

merged_df['cosine_similarity'] = similarities

import matplotlib.pyplot as plt

merged_df['potential_bias_flag'] = merged_df['cosine_similarity'] < 0.90

# ---------------------------
# Step 4b: Aggregate / Analyze
# ---------------------------
# Average similarity by client_id, gender, race, age
agg_df = merged_df.groupby(['client_id', 'gender', 'race','age']).agg(
    mean_similarity=('cosine_similarity', 'mean'),
    min_similarity=('cosine_similarity', 'min'),
    max_similarity=('cosine_similarity', 'max')
).reset_index()


import matplotlib.pyplot as plt

plt.figure(figsize=(8,5))
plt.hist(merged_df['cosine_similarity'], bins=30, edgecolor='black')
plt.title("Distribution of Cosine Similarity")
plt.xlabel("Cosine Similarity")
plt.ylabel("Frequency")
plt.show()

plt.figure(figsize=(10,5))
plt.scatter(range(len(merged_df)), merged_df['cosine_similarity'])
plt.axhline(0.90, color='red', linestyle='--', label='Bias Flag Threshold')
plt.title("Cosine Similarity Across Responses")
plt.xlabel("Sample Index")
plt.ylabel("Cosine Similarity")
plt.legend()
plt.show()

plt.figure(figsize=(8,5))
merged_df.boxplot(column='cosine_similarity', by='gender')
plt.axhline(0.90, color='red', linestyle='--')
plt.title("Cosine Similarity by Gender")
plt.suptitle("")
plt.ylabel("Cosine Similarity")
plt.show()

plt.figure(figsize=(8,5))
merged_df.boxplot(column='cosine_similarity', by='race')
plt.axhline(0.90, color='red', linestyle='--')
plt.title("Cosine Similarity by Race")
plt.suptitle("")
plt.ylabel("Cosine Similarity")
plt.show()

plt.figure(figsize=(8,5))
merged_df.boxplot(column='cosine_similarity', by='age')
plt.axhline(0.90, color='red', linestyle='--')
plt.title("Cosine Similarity by Age")
plt.suptitle("")
plt.ylabel("Cosine Similarity")
plt.show()


plt.figure(figsize=(10,5))
merged_df.boxplot(column='cosine_similarity', by='client_id')
plt.axhline(0.90, color='red', linestyle='--')
plt.title("Cosine Similarity by Client ID")
plt.suptitle("")
plt.ylabel("Cosine Similarity")
plt.show()


import seaborn as sns
import matplotlib.pyplot as plt

pivot = agg_df.pivot_table(
    index='client_id',
    columns='gender',
    values='mean_similarity'
)

plt.figure(figsize=(8,6))
sns.heatmap(pivot, annot=True, vmin=0, vmax=1, cmap='coolwarm')
plt.title("Mean Similarity Heatmap (Client ID × Gender)")
plt.show()


# Save results
merged_df.to_csv("profile_similarity_scores.csv", index=False)
agg_df.to_csv("aggregated_similarity_by_group.csv", index=False)

print("Step 0-4 complete. CSVs saved with similarity scores.")


# ---------------------------
# Step 5 (Optional): Visualizations & PCA
# ---------------------------
def step5_visualizations(df, embeddings):
    # 1. Heatmap of similarities
    pivot = df.pivot_table(index='gender', columns='race', values='cosine_similarity', aggfunc='mean')
    plt.figure(figsize=(6, 4))
    sns.heatmap(pivot, annot=True, cmap='coolwarm', vmin=0.9, vmax=1.0)
    plt.title("Average Cosine Similarity by Gender & Race")
    plt.show()

    # 2. PCA of embeddings
    pca = PCA(n_components=2)
    emb_2d = pca.fit_transform(embeddings)
    df_plot = df.copy()
    df_plot['pca1'] = emb_2d[:, 0]
    df_plot['pca2'] = emb_2d[:, 1]

    plt.figure(figsize=(6, 5))
    sns.scatterplot(data=df_plot, x='pca1', y='pca2', hue='gender', style='race', s=100)
    plt.title("PCA Projection of Explanation Embeddings")
    plt.show()

# ---------------------------
# Step 6: Compare Numeric Allocations
# ---------------------------

# Merge allocations from baseline for comparison
allocations = ['stocks', 'bonds', 'cash']
merged_alloc_df = variant_df.merge(
    baseline_df[['client_id'] + allocations],
    on='client_id',
    how='left',
    suffixes=('_variant', '_baseline')
)

# Compute differences
for col in allocations:
    merged_alloc_df[f'{col}_diff'] = merged_alloc_df[f'{col}_variant'] - merged_alloc_df[f'{col}_baseline']

# Summary statistics
print("=== Allocation Differences Summary ===")
print(merged_alloc_df[[f'{c}_diff' for c in allocations]].describe())

# Optional: visualize differences
import matplotlib.pyplot as plt
import seaborn as sns

plt.figure(figsize=(12,4))
for i, col in enumerate(allocations):
    plt.subplot(1,3,i+1)
    sns.histplot(merged_alloc_df[f'{col}_diff'], bins=20, kde=True, color='skyblue')
    plt.axvline(0, color='red', linestyle='--')
    plt.title(f'{col.capitalize()} Difference (Variant - Baseline)')
plt.tight_layout()
plt.show()

# Boxplots by client_id
plt.figure(figsize=(12,4))
for i, col in enumerate(allocations):
    plt.subplot(1,3,i+1)
    sns.boxplot(x='client_id', y=f'{col}_diff', data=merged_alloc_df)
    plt.axhline(0, color='red', linestyle='--')
    plt.title(f'{col.capitalize()} Difference by Client')
plt.tight_layout()
plt.show()

# Optional: flag large deviations
threshold = 5  # e.g., differences >5% in allocations
for col in allocations:
    merged_alloc_df[f'{col}_flag'] = merged_alloc_df[f'{col}_diff'].abs() > threshold

# Save numeric comparison results
merged_alloc_df.to_csv("allocation_comparison.csv", index=False)
print("Step 6 complete. Allocation differences saved.")

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Melt the data for easier plotting
plot_df = merged_alloc_df.melt(
    id_vars=['client_id', 'gender', 'race', 'age'],
    value_vars=['stocks_diff', 'bonds_diff', 'cash_diff'],
    var_name='asset',
    value_name='diff'
)

# Replace asset names to look nicer
plot_df['asset'] = plot_df['asset'].str.replace('_diff', '').str.capitalize()

# Single combined boxplot: x=demographic, y=difference, hue=asset
demographics = ['gender', 'race', 'age']

for demo in demographics:
    sns.set(style="whitegrid")
    g = sns.catplot(
        data=plot_df,
        x=demo,
        y='diff',
        hue='asset',
        kind='box',
        height=5,
        aspect=1.5,
        palette='Set2'
    )
    # Add a horizontal line at 0
    for ax in g.axes.flat:
        ax.axhline(0, color='red', linestyle='--')
    g.fig.suptitle(f'Allocation Differences by {demo.capitalize()}')
    g.set_axis_labels(demo.capitalize(), 'Difference (Variant - Baseline)')
    g._legend.set_title('Asset')
    plt.tight_layout()
    plt.show()

    # Count manually
    num_below_07 = (merged_df['cosine_similarity'] < 0.7).sum()
    total = len(merged_df)
    fraction_below_07 = num_below_07 / total

    print(f"Profiles below 0.7 similarity: {num_below_07}/{total} = {fraction_below_07:.2f}")

    # Compare with pandas mean method
    print("Check with mean():", (merged_df['cosine_similarity'] < 0.7).mean())