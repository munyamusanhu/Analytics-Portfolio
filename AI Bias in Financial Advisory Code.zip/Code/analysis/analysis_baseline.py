import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


df = pd.read_csv("../data/results_baseline.csv")
plt.figure(figsize=(12,4))
plt.subplot(1,3,1)
sns.histplot(df['stocks'], bins=10, kde=True, color='blue')
plt.title('Stocks Allocation')

plt.subplot(1,3,2)
sns.histplot(df['bonds'], bins=10, kde=True, color='green')
plt.title('Bonds Allocation')

plt.subplot(1,3,3)
sns.histplot(df['cash'], bins=10, kde=True, color='orange')
plt.title('Cash Allocation')

plt.tight_layout()
plt.show()
import matplotlib.pyplot as plt
import seaborn as sns

# Scatterplots by client_id
plt.figure(figsize=(12,4))

plt.subplot(1,3,1)
sns.scatterplot(x='client_id', y='stocks', data=df, s=100, color='blue')
plt.title('Stocks by Client ID')
plt.xticks(rotation=45)

plt.subplot(1,3,2)
sns.scatterplot(x='client_id', y='bonds', data=df, s=100, color='green')
plt.title('Bonds by Client ID')
plt.xticks(rotation=45)

plt.subplot(1,3,3)
sns.scatterplot(x='client_id', y='cash', data=df, s=100, color='orange')
plt.title('Cash by Client ID')
plt.xticks(rotation=45)

plt.tight_layout()
plt.show()

