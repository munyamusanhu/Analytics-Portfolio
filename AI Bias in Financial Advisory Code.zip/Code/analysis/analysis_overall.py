import pandas as pd
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from sentence_transformers import SentenceTransformer
import os
import re


# ---------------------------
# Helper functions
# ---------------------------
def clean_text(text):
    text = str(text).lower()
    text = re.sub(r'[^\w\s]', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def summarize_baseline(baseline_df, experiment_name="Baseline"):
    """
    Returns a row for the baseline itself.
    Allocation differences = 0, cosine similarity = 1
    """
    summary = {
        'Experiment': experiment_name,
        'Num Profiles': len(baseline_df),
        'Demographic Features': "Baseline",
        'Temperature': 0,
        'Stocks Mean Diff': 0.0,
        'Bonds Mean Diff': 0.0,
        'Cash Mean Diff': 0.0,
        'Allocation SD': 0.0,
        'Cosine Similarity Mean': 1.0,
        'Cosine Similarity SD': 0.0,
        'Fraction < 0.9': 0.0
    }
    return summary


def summarize_experiment_relative(exp_csv, baseline_df, baseline_embeddings, experiment_name,
                                  demographics, temperature, model):
    """
    Summarizes allocation and explanation differences for an experiment CSV relative to baseline.
    """
    # Load experiment CSV
    exp_df = pd.read_csv(exp_csv)

    # Merge allocations and baseline explanations
    merged = exp_df.merge(
        baseline_df[['client_id', 'stocks', 'bonds', 'cash', 'explanation_clean']],
        on='client_id', suffixes=('', '_baseline')
    )
    merged['stocks'] = pd.to_numeric(merged['stocks'], errors='coerce')
    merged['bonds'] = pd.to_numeric(merged['bonds'], errors='coerce')
    merged['cash'] = pd.to_numeric(merged['cash'], errors='coerce')
    merged['stocks'] = pd.to_numeric(merged['stocks_baseline'], errors='coerce')
    merged['bonds'] = pd.to_numeric(merged['bonds_baseline'], errors='coerce')
    merged['cash'] = pd.to_numeric(merged['cash_baseline'], errors='coerce')

    # Compute allocation differences
    merged['stocks_diff'] = merged['stocks'] - merged['stocks_baseline']
    merged['bonds_diff'] = merged['bonds'] - merged['bonds_baseline']
    merged['cash_diff'] = merged['cash'] - merged['cash_baseline']
    allocations = ['stocks_diff', 'bonds_diff', 'cash_diff']

    # Align baseline embeddings to merged client_ids
    baseline_index_map = {cid: idx for idx, cid in enumerate(baseline_df['client_id'])}
    baseline_emb_aligned = [baseline_embeddings[baseline_index_map[cid]] for cid in merged['client_id']]

    # Encode variant explanations
    variant_embeddings = model.encode(merged['explanation'].apply(clean_text).tolist())

    # Compute cosine similarity
    similarities = [cosine_similarity([b], [v])[0][0] for b, v in zip(baseline_emb_aligned, variant_embeddings)]
    merged['cosine_similarity'] = similarities

    # Prepare summary
    summary = {
        'Experiment': experiment_name,
        'Num Profiles': len(merged),  # actual number of rows
        'Demographic Features': demographics,
        'Temperature': temperature,
        'Stocks Mean Abs Diff': merged['stocks_diff'].mean(),
        'Bonds Mean Abs Diff': merged['bonds_diff'].mean(),
        'Cash Mean Abs Diff': merged['cash_diff'].mean(),
        'Allocation SD': merged[allocations].stack().std(),
        'Cosine Similarity Mean': merged['cosine_similarity'].mean(),
        'Cosine Similarity SD': merged['cosine_similarity'].std(),
        'Fraction < 0.9': (merged['cosine_similarity'] < 0.9).mean(),
        'Fraction < 0.8': (merged['cosine_similarity'] < 0.8).mean(),
        'Fraction < 0.7': (merged['cosine_similarity'] < 0.7).mean()
    }

    return summary


# ---------------------------
# Load baseline CSV
# ---------------------------
baseline_csv = "../data/results_baseline.csv"
baseline_df = pd.read_csv(baseline_csv)
baseline_df['explanation_clean'] = baseline_df['explanation'].apply(clean_text)

# Generate baseline embeddings once
model = SentenceTransformer('all-MiniLM-L6-v2')
baseline_embeddings = model.encode(baseline_df['explanation_clean'].tolist())

# ---------------------------
# Define experiments (ensure unique names)
# ---------------------------
experiments = [
    {"csv": "../data/results_demog_temp0.csv", "name": "Results 1 Temp 0", "demographics": "Gender+Race+Age", "temp": 0},
    {"csv": "../data/results_demog_temp1.csv", "name": "Results 1 Temp 1", "demographics": "Gender+Race+Age", "temp": 1},
    {"csv": "../data/trial2/results_demog_temp0_noage.csv", "name": "Results 2 Temp 0", "demographics": "Gender+Race",
     "temp": 0},
    {"csv": "../data/trial2/results_demog_temp1_noage.csv", "name": "Results 2 Temp 1", "demographics": "Gender+Race",
     "temp": 1},
    {"csv": "../data/trial3/results_demog_temp0_noage_newprompt.csv", "name": "Results 3 Temp 0",
     "demographics": "Gender+Race", "temp": 0},
    {"csv": "../data/trial3/results_demog_temp1_noage_newprompt.csv", "name": "Results 3 Temp 1",
     "demographics": "Gender+Race", "temp": 1},
]

# ---------------------------
# Summarize baseline + experiments
# ---------------------------
summary_rows = []

# Add baseline row
summary_rows.append(summarize_baseline(baseline_df))

# Summarize each experiment relative to baseline
for exp in experiments:
    if os.path.exists(exp['csv']):
        summary_rows.append(
            summarize_experiment_relative(
                exp_csv=exp['csv'],
                baseline_df=baseline_df,
                baseline_embeddings=baseline_embeddings,
                experiment_name=exp['name'],
                demographics=exp['demographics'],
                temperature=exp['temp'],
                model=model
            )
        )
    else:
        print(f"Warning: {exp['csv']} not found. Skipping.")

# ---------------------------
# Combine and save summary
# ---------------------------
summary_df = pd.DataFrame(summary_rows)
summary_df.to_csv("all_experiments_vs_baseline_summary.csv", index=False)

print("Summary table including baseline and experiments:")
print(summary_df)