1. Create and activate a virtual environment 
2. Create a .env file and define the variable "PROJECT_API_KEY" with your Google Gemini key. 
3. Install dependencies with "pip install -r requirements.txt"
4. To create the client profiles for the trials, run data/expanded_profiles.py
5. data/baseline_profiles.xlsx and data/demographics.xlsx are the data defined by us prior to sending API calls.
6. API calls scripts for each of the following trials can be run using the following files:
   1. data/01_baseline_trial.py for baseline data
   2. data/02_trial01_temperature0.py for trial 1 temp 0
   3. data/03_trial01_temperature1.py for trial 1 temp 1
   4. data/trial2/test2_noage.py for trial 2 temp 0
   5. data/trial2/test2_temp1_noage.py for trial 2 temp 1
   6. data/trial3/test2_noage.py for trial 3 temp 0
   7. data/trial3/test2_temp1_noage.py for trial 3 temp 1
7. For analysis purposes, the following files can be run under the analysis folder:
   1. analysis.py: generates semantic embeddings, cosine similarity, and visualizations for a single comparison
   2. analysis_baseline.py: analyzes portfolio allocations of baseline results 
   3. analysis_overall.py: creates summary table for portfolio allocations and cosine similarity
   4. analysis_portfolio_allocation.py: ANOVA and t-test analysis of the portfolio allocation
MAIN.py file 